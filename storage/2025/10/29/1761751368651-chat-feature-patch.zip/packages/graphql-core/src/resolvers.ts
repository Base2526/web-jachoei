import { withFilter } from "graphql-subscriptions";
import { pubsub } from "../../realtime/src/pubsub.js";

export const coreResolvers = {
  Query: { _ok: () => "ok" },

  Mutation: {
    sendMessage: async (_: unknown, { chatId, text }: { chatId: string; text: string }, ctx: any) => {
      const msg = {
        id: Date.now().toString(),
        chatId,
        senderId: ctx?.userId || "demo",
        text,
        ts: new Date().toISOString()
      };
      await pubsub.publish("MSG", { messageAdded: msg });
      return true;
    },
  },

  Subscription: {
    messageAdded: {
      subscribe: withFilter(
        () => pubsub.asyncIterator("MSG"),
        (payload, variables) => {
          return payload?.messageAdded?.chatId === variables?.chatId;
        }
      )
    }
  },
};
