import { query } from "@/lib/db";
import { pubsub } from "../../../packages/realtime/src/pubsub.js";

async function currentUserId(){
  const { rows } = await query(`SELECT id FROM users WHERE email='bob@example.com' LIMIT 1`);
  return rows[0]?.id;
}

export const resolvers = {
  Query: {
    _health: () => "ok",
    meRole: async (_:any, __:any, ctx:any) => ctx.role || "Subscriber",

    posts: async (_:any, { search }:{search?:string}) => {
      if (search) {
        const { rows } = await query(
          `SELECT p.*, row_to_json(u.*) as author_json
           FROM posts p LEFT JOIN users u ON p.author_id = u.id
           WHERE p.title ILIKE $1 OR p.phone ILIKE $1
           ORDER BY p.created_at DESC`, ['%' + search + '%']
        );
        return rows.map(r=>({ ...r, author: r.author_json }));
      }
      const { rows } = await query(
        `SELECT p.*, row_to_json(u.*) as author_json
         FROM posts p LEFT JOIN users u ON p.author_id = u.id
         ORDER BY p.created_at DESC`
      );
      return rows.map(r=>({ ...r, author: r.author_json }));
    },

    post: async (_:any, { id }:{id:string}) => {
      const { rows } = await query(
        `SELECT p.*, row_to_json(u.*) as author_json
         FROM posts p LEFT JOIN users u ON p.author_id = u.id
         WHERE p.id = $1`, [id]
      );
      const r = rows[0]; if (!r) return null;
      return { ...r, author: r.author_json };
    },

    myChats: async () => {
      const me = await currentUserId();
      const { rows } = await query(
        `SELECT c.*, row_to_json(uc.*) as creator_json
         FROM chats c 
         LEFT JOIN users uc ON c.created_by = uc.id
         WHERE EXISTS (SELECT 1 FROM chat_members m WHERE m.chat_id = c.id AND m.user_id = $1)
         ORDER BY c.created_at DESC`, [me]
      );
      const out:any[] = [];
      for (const c of rows){
        const mem = await query(
          `SELECT u.* FROM chat_members m JOIN users u ON m.user_id=u.id WHERE m.chat_id=$1`, [c.id]
        );
        out.push({ 
          ...c, 
          created_by: c.creator_json, 
          members: mem.rows 
        });
      }
      return out;
    },

    messages: async (_:any, { chatId, limit=50, offset=0 }:{chatId:string, limit?:number, offset?:number}) => {
      const { rows } = await query(
        `SELECT m.*, row_to_json(u.*) as sender_json
         FROM messages m LEFT JOIN users u ON m.sender_id=u.id
         WHERE m.chat_id=$1
         ORDER BY m.created_at ASC
         LIMIT $2 OFFSET $3`, [chatId, limit, offset]
      );
      return rows.map(r=>({ ...r, sender: r.sender_json }));
    }
  },

  Mutation: {
    upsertPost: async (_:any, { id, data }:{id?:string, data:any}, ctx:any) => {
      const { rows:au } = await query(`SELECT id FROM users WHERE email='bob@example.com' LIMIT 1`);
      const author_id = au[0]?.id;
      if (id) {
        const { rows } = await query(
          `UPDATE posts SET title=$1, body=$2, image_url=$3, phone=$4, status=$5, updated_at=NOW()
           WHERE id=$6 RETURNING *`,
          [data.title, data.body, data.image_url, data.phone, data.status, id]
        );
        return rows[0];
      } else {
        const { rows } = await query(
          `INSERT INTO posts (title, body, image_url, phone, status, author_id)
           VALUES ($1,$2,$3,$4,$5,$6) RETURNING *`,
          [data.title, data.body, data.image_url, data.phone, data.status, author_id]
        );
        return rows[0];
      }
    },

    deletePost: async (_:any, { id }:{id:string}) => {
      const res = await query(`DELETE FROM posts WHERE id=$1`, [id]);
      return res.rowCount === 1;
    },

    createChat: async (_:any, { name, isGroup, memberIds }:{name?:string, isGroup:boolean, memberIds:string[]}) => {
      const me = await currentUserId();
      const { rows } = await query(
        `INSERT INTO chats (name, is_group, created_by) VALUES ($1,$2,$3) RETURNING *`,
        [name || null, isGroup, me]
      );
      const chat = rows[0];
      const allMembers = Array.from(new Set([me, ...memberIds]));
      for (const uid of allMembers){
        await query(`INSERT INTO chat_members (chat_id, user_id) VALUES ($1,$2) ON CONFLICT DO NOTHING`, [chat.id, uid]);
      }
      const mem = await query(
        `SELECT u.* FROM chat_members m JOIN users u ON m.user_id=u.id WHERE m.chat_id=$1`, [chat.id]
      );
      const creator = await query(`SELECT * FROM users WHERE id=$1`, [chat.created_by]);
      return { ...chat, created_by: creator.rows[0], members: mem.rows };
    },

    addMember: async (_:any, { chatId, userId }:{chatId:string, userId:string}) => {
      await query(`INSERT INTO chat_members (chat_id, user_id) VALUES ($1,$2) ON CONFLICT DO NOTHING`, [chatId, userId]);
      return true;
    },

    sendMessage: async (_:any, { chatId, text }:{chatId:string, text:string}) => {
      const me = await currentUserId();
      const { rows } = await query(
        `INSERT INTO messages (chat_id, sender_id, text) VALUES ($1,$2,$3) RETURNING *`,
        [chatId, me, text]
      );
      const msg = rows[0];
      const senderQ = await query(`SELECT * FROM users WHERE id=$1`, [msg.sender_id]);
      const shaped = { id: msg.id, chat_id: msg.chat_id, sender: senderQ.rows[0], text: msg.text, created_at: msg.created_at };
      await pubsub.publish("MSG", { messageAdded: { id: msg.id, chatId, senderId: msg.sender_id, text: msg.text, ts: new Date(msg.created_at).toISOString() } });
      return shaped;
    }
  }
};
